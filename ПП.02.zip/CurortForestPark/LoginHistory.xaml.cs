﻿using CurortForestPark.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace CurortForestPark
{
    /// <summary>
    /// Логика взаимодействия для LoginHistory.xaml
    /// </summary>
    public partial class LoginHistory : Window
    {
        string m;
        List<Entities.LoginHistory> login;
        public LoginHistory()
        {
            InitializeComponent();
            _timer = new DispatcherTimer();
            _timer.Interval = TimeSpan.FromMilliseconds(100); // Интервал в миллисекундах
            _timer.Tick += Timer_Tick;
            _timer.Start();
            List<String> strings = new List<String>();
            try
            {
                foreach (var @event in entities.Users)
                {
                    m = @event.Login;
                    if (strings.Count == 0)
                    {
                        strings.Add(m);
                    }
                    foreach (String s in strings)
                    {
                        if (!strings.Contains(m))
                        {
                            strings.Add(m);
                            break;
                        }
                    }
                }
                for (int i = 0; i < strings.Count; i++)
                {
                    CmboxFilter.Items.Add(strings[i]);

                }
                Update();
               
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        Entities.Entities entities = new Entities.Entities();
        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            OrdersWindow ordersWindow = new OrdersWindow();
            ordersWindow.Show();
            this.Close();
        }
        private DispatcherTimer _timer;
        private void Timer_Tick(object sender, EventArgs e)
        {
            // Этот код выполняется каждые 100 мс
            TimeBlock.Text = UserStuff.timelapse;
        }
       

        private void Update()
        {
            login = entities.LoginHistory.ToList();
            Filter();
            ClientView.ItemsSource = login;
        }
        private void Filter()
        {
            if (CmboxFilter.SelectedIndex == -1 | CmboxFilter.SelectedIndex == 0)
            {

            }

            else
            {
                string s = CmboxFilter.SelectedItem.ToString();
                login = login.Where(p => p.Users.Login == s).ToList();

            }
        }
        private void Button_Click(object sender, RoutedEventArgs e)
        {
           

            MainWindow mainWindow = new MainWindow();
            mainWindow.Show();
            this.Close();
        }

        private void CmboxFilter_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            Update();
        }

       
    }
}
