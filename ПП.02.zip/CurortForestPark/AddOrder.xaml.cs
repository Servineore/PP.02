﻿using CurortForestPark.Entities;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace CurortForestPark
{
    /// <summary>
    /// Логика взаимодействия для AddOrder.xaml
    /// </summary>
    public partial class AddOrder : Window
    {
        string aba;
        string date;
        string code;
        int count = 0;
        public AddOrder()
        {
            InitializeComponent();
            this.DataContext = orders;
            ClientBox.ItemsSource = entities.Clients.ToList();
            OrderBox.ItemsSource = entities.OrderStatuses.ToList();
            List<Services> services = new List<Services>();
            var names = entities.Services.ToList();
            foreach (Services service in names)
            {
                GridDevs.Items.Add(service.Name);
            }
        }
        Entities.Entities entities = new Entities.Entities();
        Orders orders = new Orders();
        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            try
            {
                Button button = sender as Button; 
                string itemToRemove = button.Tag as string; //Находим название услуги
                if (itemToRemove != null && ListBoxDevs.Items.Contains(itemToRemove))
                {
                ListBoxDevs.Items.Remove(itemToRemove); //Удаляем услугу
                    count--;
                MessageBox.Show("Услуга удалена");
                    
                }
            }
            catch
            (Exception ex)
            { MessageBox.Show(ex.Message); }
        }
        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            try
            {
                if (GridDevs.SelectedIndex != -1)
                {
                  
                    ListBoxDevs.Items.Add(GridDevs.SelectedItem.ToString()); //Добавляем услугу из выпадающего списка
                    count++;
                    MessageBox.Show("Услуга успешно добавлена");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private void BtnAdd_Click(object sender, RoutedEventArgs e)
        {
            PanelAdd.Visibility = Visibility.Visible;
        }

        private void MinusButton_Click(object sender, RoutedEventArgs e)
        {
            PanelAdd.Visibility = Visibility.Collapsed;
            GridDevs.SelectedIndex = -1;
        }

        private void DatePicker_SelectedDateChanged(object sender, SelectionChangedEventArgs e)
        {

             date = CreateDate.SelectedDate.Value.ToShortDateString();             
             aba = code + "/" + date;
            NumberBox.Text = aba;
        }

        private void ClientBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
 
             code = ClientBox.SelectedValue?.ToString();
             aba = code + "/" + date;
            NumberBox.Text = aba;
            
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            SellerWindow sellerWindow = new SellerWindow();
            sellerWindow.Show();
            this.Close();
        }

        private void Button_Click_3(object sender, RoutedEventArgs e)
        {
            try
            {
                string error = "";
                string time = @"^([01]?[0-9]|2[0-3]):([0-5][0-9]):([0-5][0-9])$";
                if (CreateDate.SelectedDate == null || String.IsNullOrWhiteSpace(CreateTime.Text)
                    || ClientBox.SelectedIndex == -1
                    || OrderBox.SelectedIndex == -1) // Пустые значения
                    error += "Все поля, кроме даты закрытия и времени проката должны быть заполнены \n";
                if (!int.TryParse(Time.Text, out int number) & !String.IsNullOrWhiteSpace(Time.Text)) // Проверка цифр во времени проката
                {
                    error += "Во времени проката должны использоваться только цифры \n";
                }
                if (!Regex.IsMatch(CreateTime.Text, time)) // Проверка написания времени в правильном формате
                    error += "Время создания должно быть записано в формате HH:MM:SS \n";
                if (count <= 0) //Кол-во услуг в заказе
                {
                    error += "В заказе должна быть хотя бы одна услуга \n";
                }
                if (error == "")
                {
                    orders.Number = NumberBox.Text;
                    entities.Orders.Add(orders); //Добавляем заказ
                    entities.SaveChanges();
                    List<string> strings;
                    CreateOrderWithServices(); //Получаем услуги в listbox, добавляем их orderservices и сохраняем полученные данные

                    SellerWindow sellerWindow = new SellerWindow();
                    sellerWindow.Show();
                    this.Close();
                }
                else
                {
                    MessageBox.Show(error);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }
       
        public void CreateOrderWithServices()
        {
           
                var serviceNames = ListBoxDevs.Items.Cast<string>().ToList();

                // Получаем услуги из БД
                var services = entities.Services
                    .Where(s => serviceNames.Contains(s.Name))
                    .ToList();

     

            var order = entities.Orders.ToList();
                // Добавляем услуги к заказу
                foreach (var service in services)
                {
                MessageBox.Show(service.Id.ToString());
                OrderServices orderServices = new OrderServices();
                orderServices.OrderID = order.Last().Id;
                orderServices.ServiceID = service.Id;
                    entities.OrderServices.Add(orderServices);
                entities.SaveChanges();
                }

                
             

                MessageBox.Show($"Заказ создан с {services.Count} услугами");
            }
        }

    }

