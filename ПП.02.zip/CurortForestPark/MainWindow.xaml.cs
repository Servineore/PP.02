﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Threading;
using Brush = System.Drawing.Brush;

namespace CurortForestPark
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        bool isClosed = false;
        int lost = 1;
        int i = 1;
        DispatcherTimer dispatcherTimer;
        int seconds = 0;
        public MainWindow()
        {
            InitializeComponent();
            dispatcherTimer = new System.Windows.Threading.DispatcherTimer();
            dispatcherTimer.Tick += new EventHandler(dispatcherTimer_Tick);
            dispatcherTimer.Interval = TimeSpan.FromSeconds(1);
            //foreach (var photo in entities.Users) Код для добавления картинок
            //{
            //    string path = @"C:\Users\ПК\Desktop\Сотрудники_import\" + i + ".jpeg";
            //    byte[] image = System.IO.File.ReadAllBytes(path);
            //    photo.Photo = image;
            //}
            //entities.SaveChanges();
        }
        private void dispatcherTimer_Tick(object sender, EventArgs e)
        {
            seconds++;
            JoinButton.Content = "Вход " + (5 - seconds);
            if (seconds == 5)
            {
                this.IsEnabled = true;
                seconds = 0;
                JoinButton.Content = "Вход";
                dispatcherTimer.Stop();
            }
        }
        

        private void LoginBtn_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (entities.Users.Any(p => p.Login == LoginBox.Text & p.Password == PasswordBox.Password) & CaptchaBox.Text == this.text) // Проверка логина и пароля пользователя
                {
                    var user = entities.Users.Where(p => p.Login == LoginBox.Text & p.Password == PasswordBox.Password).FirstOrDefault(); // Получение данных пользователя
                    user.LoginDate = DateTime.Now;// Изменения даты входа пользователя


                    TimeSpan timeWithoutMs = DateTime.Now.TimeOfDay;
                    timeWithoutMs = new TimeSpan(timeWithoutMs.Hours, timeWithoutMs.Minutes, timeWithoutMs.Seconds);

                    user.LoginTime = timeWithoutMs; //Изменение времени входа пользователя
                    UserStuff.LoginDate = DateTime.Now;
                    UserStuff.LoginTime = timeWithoutMs;
                    UserStuff.FullName = user.FullName;
                    UserStuff.id = user.Id; //Данные пользователя для последующего добавления данных в историю входа, а также для вывода ФИО и фотографии
                    entities.SaveChanges();
                        MessageBox.Show("Добро пожаловать");
                    UserStuff.Timer(); //Запуск глобального таймера
                        if (user.Job == 1) // Проверки на роль пользователя и переход на соответствующее окно  
                        {
                            LoginHistory devMainWindow = new LoginHistory();
                            devMainWindow.Show();
                            this.Close();
                        }
                        else
                        {
                            SellerWindow projectWindow = new SellerWindow();
                            projectWindow.Show();
                            this.Close();
                        }
                       
                    
                }
                else
                {
                    MessageBox.Show("Неправильный логин или пароль или введена неправильная капча ");
                    lost++;
                    CheckBlock();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        Entities.Entities entities = new Entities.Entities();

        private void CheckBlock()
        {
            if (lost >= 3)
            {
                this.IsEnabled = false;
                dispatcherTimer.Start();
                lost = 1;
            }
        }
        private void PasswordBox_PreviewKeyDown(object sender, KeyEventArgs e)
        {

            if (TexPassbox.Text == null | PasswordBox.Password == null)
            {
                Eyebutton.Visibility = Visibility.Collapsed;
            }
            else
            {
                Eyebutton.Visibility = Visibility.Visible;
            }
        }
        private string text = String.Empty;
        private Bitmap CreateImage(int Width, int Height)
        {
            Random rnd = new Random();

            //Создадим изображение
            Bitmap result = new Bitmap(Width, Height);

            //Вычислим позицию текста
            int Xpos = rnd.Next(0, Width - 50);
            int Ypos = rnd.Next(15, Height - 15);

            //Добавим различные цвета
            Brush[] colors = { System.Drawing.Brushes.Black,
                     System.Drawing.Brushes.Red,
                     System.Drawing.Brushes.RoyalBlue,
                     System.Drawing.Brushes.Green };

            //Укажем где рисовать
            Graphics g = Graphics.FromImage((System.Drawing.Image)result);

            //Пусть фон картинки будет серым
            g.Clear(System.Drawing.Color.White);

            //Сгенерируем текст
            text = String.Empty;
            string ALF = "1234567890QWERTYUIOPASDFGHJKLZXCVBNM";
            for (int i = 0; i < 5; ++i)
                text += ALF[rnd.Next(ALF.Length)];

            //Нарисуем сгенирируемый текст
            g.DrawString(text,
                         new Font("Arial", 15),
                         colors[rnd.Next(colors.Length)],
                         new PointF(Xpos, Ypos));

            //Добавим немного помех
            /////Линии из углов
            g.DrawLine(Pens.Black,
                       new System.Drawing.Point(0, 0),
                       new System.Drawing.Point(Width - 1, Height - 1));
            g.DrawLine(Pens.Black,
                       new System.Drawing.Point(0, Height - 1),
                       new System.Drawing.Point(Width - 1, 0));
            ////Белые точки
            for (int i = 0; i < Width; ++i)
                for (int j = 0; j < Height; ++j)
                    if (rnd.Next() % 20 == 0)
                        result.SetPixel(i, j, System.Drawing.Color.White);

            return result;
        }
        public static class BitmapConverter
        {
            public static BitmapImage BitmapToImageSource(Bitmap bitmap)
            {
                using (var memory = new MemoryStream())
                {
                    // Сохраняем Bitmap в MemoryStream
                    bitmap.Save(memory, ImageFormat.Png);
                    memory.Position = 0;

                    // Создаем BitmapImage
                    var bitmapImage = new BitmapImage();
                    bitmapImage.BeginInit();
                    bitmapImage.StreamSource = memory;
                    bitmapImage.CacheOption = BitmapCacheOption.OnLoad;
                    bitmapImage.EndInit();
                    bitmapImage.Freeze(); // Опционально: для использования в разных потоках

                    return bitmapImage;
                }
            }

        }
            
        private void Eyebutton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (!isClosed)
                {
                  
                    isClosed = true;
                    PasswordBox.Visibility = Visibility.Collapsed;
                    TexPassbox.Visibility = Visibility.Visible;
                    TexPassbox.Text = PasswordBox.Password;
                }
                else
                {
               
                    isClosed = false;
                    PasswordBox.Visibility = Visibility.Visible;
                    TexPassbox.Visibility = Visibility.Collapsed;
                    PasswordBox.Password = TexPassbox.Text;
                }
            }
            catch
            {
                MessageBox.Show("Ошибка с глазами");
            }
        }


        private void PasswordBox_KeyUp(object sender, KeyEventArgs e)
        {
            try
            {
                if (String.IsNullOrWhiteSpace(TexPassbox.Text) & String.IsNullOrWhiteSpace(PasswordBox.Password))
                {
                    Eyebutton.Visibility = Visibility.Collapsed;
                }
                else
                {
                    Eyebutton.Visibility = Visibility.Visible;
                }
                if (TexPassbox.Visibility == Visibility.Collapsed)
                {
                    TexPassbox.Text = PasswordBox.Password;
                }
                else
                {
                    PasswordBox.Password = TexPassbox.Text;
                }
            }
            catch
            {
                MessageBox.Show("Раз в год и у палки error");
            }
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            CaptchaImage.Source = BitmapConverter.BitmapToImageSource(this.CreateImage(Convert.ToInt32(CaptchaImage.Width), Convert.ToInt32(CaptchaImage.Height)));
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            CaptchaImage.Source = BitmapConverter.BitmapToImageSource(this.CreateImage(Convert.ToInt32(CaptchaImage.Width), Convert.ToInt32(CaptchaImage.Height)));
        }
    }

}

