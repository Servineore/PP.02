﻿using CurortForestPark.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace CurortForestPark
{
    /// <summary>
    /// Логика взаимодействия для AddClient.xaml
    /// </summary>
    public partial class AddClient : Window
    {
        public AddClient()
        {
            InitializeComponent();
            this.DataContext = clients;
            BirthDate.BlackoutDates.Add(new CalendarDateRange(DateTime.Now.AddYears(-18),DateTime.Now));
            BirthDate.BlackoutDates.Add(new CalendarDateRange(new DateTime(0001,01,01),new DateTime(1920,01,01)));
            BirthDate.BlackoutDates.Add(new CalendarDateRange(DateTime.Now, new DateTime(9999, 12, 12)));
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                string mail = @"^(?("")(""[^""]+?""@)|(([0-9a-z]((\.(?!\.))|[-!#\$%&'\*\+/=\?\^`\{\}\|~\w])*)(?<=[0-9a-z])@))" +
                    @"(?(\[)(\[(\d{1,3}\.){3}\d{1,3}\])|(([0-9a-z][-\w]*[0-9a-z]*\.)+[a-z0-9]{2,17}))$"; //Выражение на проверку почты
                string error = "";
                string pattern = @"^[А-ЯЁ][а-яё]+\s[А-ЯЁ][а-яё]+\s[А-ЯЁ][а-яё]+$"; // Выражение на проверку Фио
                if (String.IsNullOrWhiteSpace(FullName.Text) || String.IsNullOrWhiteSpace(Series.Text) || String.IsNullOrWhiteSpace(Number.Text)
                    || String.IsNullOrWhiteSpace(Mail.Text)
                    || String.IsNullOrWhiteSpace(Address.Text)
                    || BirthDate.SelectedDate == null) // Проверка пустых данных
                {
                    error += "все поля обязательно для заполнения \n";
                }
                if (!int.TryParse(Number.Text, out int number) || !int.TryParse(Series.Text, out int nu)) // Проверка серии и номера паспорта
                {
                    error += "серия и номер должны содержать только цифры \n";
                }
                if (!Regex.IsMatch(FullName.Text, pattern))
                    error += "неправильно введено ФИО \n";
                if (!Regex.IsMatch(Mail.Text, mail))
                    error += "Неправильно написана почта \n";
                if (error == "")
                {

                    var usercode = entities.Clients.ToList();
                    clients.Code = usercode.Last().Code + 1;
                    entities.Clients.Add(clients);
                    entities.SaveChanges();
                    MessageBox.Show("Новый клиент зарегистрирован в системе");
                    this.Close();

                }
                else
                {
                    MessageBox.Show(error);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        Entities.Entities entities = new Entities.Entities(); 
        Clients clients = new Clients();
        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            UserWindow userWindow = new UserWindow();
            userWindow.Show();
            this.Close();
        }
    }
}
