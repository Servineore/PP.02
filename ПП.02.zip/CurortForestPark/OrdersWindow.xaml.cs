﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace CurortForestPark
{
    /// <summary>
    /// Логика взаимодействия для OrdersWindow.xaml
    /// </summary>
    public partial class OrdersWindow : Window
    {
        public OrdersWindow()
        {
            InitializeComponent();
            ClientView.ItemsSource = entities.Orders.ToList();
            _timer = new DispatcherTimer();
            _timer.Interval = TimeSpan.FromMilliseconds(100); // Интервал в миллисекундах
            _timer.Tick += Timer_Tick;
            _timer.Start();
        }
        Entities.Entities entities = new Entities.Entities();
        private DispatcherTimer _timer;
        private void Timer_Tick(object sender, EventArgs e)
        {
            // Этот код выполняется каждые 100 мс
            TimeBlock.Text = UserStuff.timelapse;
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            LoginHistory loginHistory = new LoginHistory();
            loginHistory.Show();
            this.Close();
        }

        private void Window_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
          
        }
    }
}
