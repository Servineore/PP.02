﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace CurortForestPark
{
    /// <summary>
    /// Логика взаимодействия для SellerWindow.xaml
    /// </summary>
    public partial class SellerWindow : Window
    {
        public SellerWindow()
        {
            InitializeComponent();
            FullName.Text = "Добро пожаловать " + UserStuff.FullName + "!";
        
        _timer = new DispatcherTimer();
        _timer.Interval = TimeSpan.FromMilliseconds(100); // Интервал в миллисекундах
            _timer.Tick += Timer_Tick;
            _timer.Start();
            var user = entities.Users.Where(p => p.Id == UserStuff.id).FirstOrDefault();
            ImageUser.Source = LoadImage(user.Photo);
        }
        private static BitmapImage LoadImage(byte[] imageData)
        {
            try
            {
                if (imageData == null || imageData.Length == 0) return null;
                var image = new BitmapImage();
                using (var mem = new MemoryStream(imageData))
                {
                    mem.Position = 0;
                    image.BeginInit();
                    image.CreateOptions = BitmapCreateOptions.PreservePixelFormat;
                    image.CacheOption = BitmapCacheOption.OnLoad;
                    image.UriSource = null;
                    image.StreamSource = mem;
                    image.EndInit();
                }
                image.Freeze();
                return image;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Значит без фото");
                return null;
            }
        }
        Entities.Entities entities = new Entities.Entities(); 
        private DispatcherTimer _timer;
        private void Timer_Tick(object sender, EventArgs e)
        {
           
            TimeBlock.Text = UserStuff.timelapse;
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            AddOrder addOrder = new AddOrder();
            addOrder.ShowDialog();
           
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            UserWindow user = new UserWindow();
            user.Show();
            this.Close();
        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            UserStuff.AddLoginHistory();
            
            MainWindow mainWindow = new MainWindow();
            mainWindow.Show();
            this.Close();
        }

        private void Window_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
           
        }
    }
}
