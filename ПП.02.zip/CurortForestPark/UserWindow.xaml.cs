﻿using CurortForestPark.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace CurortForestPark
{
    /// <summary>
    /// Логика взаимодействия для UserWindow.xaml
    /// </summary>
    public partial class UserWindow : Window
    {
        List<Clients> clients;
        public UserWindow()
        {
            InitializeComponent();
            Update();
            _timer = new DispatcherTimer();
            _timer.Interval = TimeSpan.FromMilliseconds(100); // Интервал в миллисекундах
            _timer.Tick += Timer_Tick;
            _timer.Start();
        }
       
        private DispatcherTimer _timer;
        private void Timer_Tick(object sender, EventArgs e)
        {
       
            TimeBlock.Text = UserStuff.timelapse;
        }
        
        Entities.Entities entities = new Entities.Entities();
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            SellerWindow sellerWindow = new SellerWindow();
            sellerWindow.Show();
            this.Close();
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            AddClient addClient = new AddClient();
            addClient.ShowDialog();
            Update();
        }

        private void TextBox_PreviewKeyUp(object sender, KeyEventArgs e)
        {
            Update();
        }
        private void Update()
        {
            clients = entities.Clients.ToList();
            Search();
            ClientView.ItemsSource = clients;
        }
        private void Search()
        {

            if (SearchBar.Text != null)
            {
                clients = clients.Where(p => p.FullName.ToLower().Contains(SearchBar.Text.ToLower())).ToList();
            }
        }
    }
}
