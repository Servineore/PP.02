﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.NetworkInformation;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Threading;

namespace CurortForestPark
{
    public class UserStuff
    {
        public static int id { get; set; }
        public static string FullName {  get; set; } 
        public static int hours { get; set; }
        public static int minutes { get; set; }
        public static int seconds { get; set; }
        public static string timelapse { get; set; }
        public static int duration;
        public static TimeSpan LoginTime { get; set; }
        public static DateTime LoginDate { get; set; }
        public static DispatcherTimer dispatcherTimer1 = new System.Windows.Threading.DispatcherTimer();
        public static void Timer()
        {
        dispatcherTimer1.Tick += new EventHandler(dispatcherTimer_Tick);
        dispatcherTimer1.Interval = TimeSpan.FromSeconds(1);
            dispatcherTimer1.Start();
        }
        public static void dispatcherTimer_Tick(object sender, EventArgs e)
        {
            seconds++;
            if (seconds == 60)
            {
                minutes++;
                seconds = 0;
            }
            if (minutes == 60)
            {
                hours++;
                minutes = 0;
            }
            timelapse = hours + ":" + minutes + ":" + seconds; //Время, которое будет выводиться в таймер
            duration = hours * 60 + minutes; //Значение длительности сессии, которое будет записываться в базу данных
        }
        public static void AddLoginHistory()
        {
            try
            {
                Entities.Entities entities1 = new Entities.Entities();
                Entities.LoginHistory loginHistory = new Entities.LoginHistory(); //Создание нового параметра в истории входа
                loginHistory.UserID = id; // Идентификатор пользователя
                loginHistory.Duration = duration; //Длительность перед выходом
                loginHistory.LoginDate = UserStuff.LoginDate; //Дата входа
                loginHistory.LoginTime = UserStuff.LoginTime; //Время входа
                entities1.LoginHistory.Add(loginHistory); //Добавление нового значения
                entities1.SaveChanges();
                dispatcherTimer1.Stop(); //Отключение таймера
                seconds = 0; //Сброс всех данных
                minutes = 0;
                seconds = 0;
                duration = 0;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }
     
    }
}
